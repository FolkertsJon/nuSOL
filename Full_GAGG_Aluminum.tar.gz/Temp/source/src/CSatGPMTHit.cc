//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
//
/// \file optical/CSat/src/CSatGPMTHit.cc
/// \brief Implementation of the CSatGPMTHit class
//
//
#include "CSatGPMTHit.hh"

#include "G4ios.hh"
#include "G4Colour.hh"
#include "G4LogicalVolume.hh"
#include "G4VisAttributes.hh"
#include "G4VPhysicalVolume.hh"
#include "G4VVisManager.hh"

G4ThreadLocal G4Allocator<CSatGPMTHit>* CSatGPMTHitAllocator = nullptr;

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

CSatGPMTHit::CSatGPMTHit()
  : fEdepG(0.)
  , fPhysVolG(nullptr)
  , ftimeG(0.)
{}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
CSatGPMTHit::CSatGPMTHit(G4VPhysicalVolume* pVolG)
  : fPhysVolG(pVolG)
{}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

CSatGPMTHit::~CSatGPMTHit() {}
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

CSatGPMTHit::CSatGPMTHit(const CSatGPMTHit& right)
  : G4VHit()
{
  fEdepG    = right.fEdepG;
  fPhysVolG = right.fPhysVolG;
  ftimeG    = right.ftimeG;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

const CSatGPMTHit& CSatGPMTHit::operator=(const CSatGPMTHit& right)
{
  fEdepG    = right.fEdepG;
  fPhysVolG = right.fPhysVolG;
  ftimeG    = right.ftimeG;
  return *this;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
G4bool CSatGPMTHit::operator==(const CSatGPMTHit&) const
{
  return false;
  // returns false because there currently isn't need to check for equality
}
